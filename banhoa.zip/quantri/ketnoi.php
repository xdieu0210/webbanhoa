<?php  
	$dbhost="localhost";
	$dbuser="nirho7tuzxcv";
	$dbpass="Xdieu2k2@";
	$dbname="nirho7tuzxcv_banhoa_uneti_14a11";

	$conn=mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
	if($conn){
		$setLang=mysqli_query($conn, "SET NAMES 'utf8'");
	}
	else{
		die("kết nối thất bại!".mysqli_connect_error());
	}
?>