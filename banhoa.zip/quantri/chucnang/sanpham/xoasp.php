<?php
	session_start();  
	ob_start();
     session_start();
     include_once'../../ketnoi.php';
     if(isset($_SESSION['email']) && isset($_SESSION['pass'])){
         $email = $_SESSION['email'];
         $passs = $_SESSION['pass'];
        
         $sql = "SELECT * FROM thanhvien WHERE email='$email' and mat_khau = '$passs'";
         $query = mysqli_query($conn,$sql);
         $row = mysqli_fetch_array($query);
 
     }
     if($row['quyen_truy_cap'] == 2 ){
		$id_sp=$_GET['id_sp'];
		include_once'../../ketnoi.php';
		$sql="DELETE FROM sanpham WHERE id_sp='$id_sp'";
		$query=mysqli_query($conn ,$sql);
		header('location: ../../quantri.php?page_layout=danhsachsp');
	}else{
		header('location: ../../index.php');
	}
?>